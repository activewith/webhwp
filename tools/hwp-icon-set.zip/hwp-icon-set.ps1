﻿# 웹 한글 편집기(PWA) 앱 아이콘을 .hwp / .hwpx 파일 아이콘으로 지정
# - 현재 사용자(HKCU)만 변경, 관리자 권한 불필요
# - 되돌리기: 같은 스크립트를 -Undo 옵션으로 실행
# 실행: powershell -ExecutionPolicy Bypass -File .\hwp-icon-set.ps1
#       powershell -ExecutionPolicy Bypass -File .\hwp-icon-set.ps1 -Undo
param([switch]$Undo)
$ErrorActionPreference = 'Stop'
$appName = '웹 한글 편집기'

function Get-WebAppProgId([string]$ext) {
    $uc = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$ext\UserChoice"
    $progId = (Get-ItemProperty -Path $uc -ErrorAction SilentlyContinue).ProgId
    if (-not $progId) { Write-Host "$ext : 기본 연결 프로그램이 지정돼 있지 않아 건너뜁니다."; return $null }
    $cmdKey = "HKCU:\Software\Classes\$progId\shell\open\command"
    $cmd = (Get-ItemProperty -Path $cmdKey -ErrorAction SilentlyContinue).'(default)'
    # Chrome/Edge가 등록한 웹앱 연결인지 확인 (한컴 등 다른 프로그램의 아이콘은 건드리지 않음)
    if (-not $cmd -or ($cmd -notmatch '--app-id' -and $cmd -notmatch 'pwa_launcher')) {
        Write-Host "$ext : 현재 기본 프로그램($progId)이 웹 한글 편집기가 아니라서 건너뜁니다."
        if ($cmd) { Write-Host "       실행 명령: $cmd" }
        return $null
    }
    return $progId
}

$exts = '.hwp', '.hwpx'

if ($Undo) {
    foreach ($ext in $exts) {
        $progId = Get-WebAppProgId $ext
        if (-not $progId) { continue }
        $key = "HKCU:\Software\Classes\$progId\DefaultIcon"
        if (Test-Path $key) { Remove-Item -Path $key -Recurse -Force; Write-Host "$ext : 아이콘 지정을 제거했습니다." }
        else { Write-Host "$ext : 제거할 아이콘 지정이 없습니다." }
    }
} else {
    $roots = @("$env:LOCALAPPDATA\Google\Chrome\User Data", "$env:LOCALAPPDATA\Microsoft\Edge\User Data") | Where-Object { Test-Path $_ }
    $ico = Get-ChildItem -Path $roots -Recurse -Filter "$appName.ico" -ErrorAction SilentlyContinue |
           Where-Object { $_.FullName -like '*Web Applications*' } |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $ico) {
        Write-Host "앱 아이콘 파일($appName.ico)을 찾지 못했습니다. Chrome에서 hwp.activewith.net을 앱으로 설치했는지 확인하세요."
        exit 1
    }
    Write-Host "앱 아이콘: $($ico.FullName)"
    foreach ($ext in $exts) {
        $progId = Get-WebAppProgId $ext
        if (-not $progId) { continue }
        $key = "HKCU:\Software\Classes\$progId\DefaultIcon"
        New-Item -Path $key -Force -Value "`"$($ico.FullName)`",0" | Out-Null
        Write-Host "$ext : 아이콘을 지정했습니다. ($progId)"
    }
}

# 탐색기 아이콘 캐시 새로 고침
Start-Process -FilePath "$env:WINDIR\System32\ie4uinit.exe" -ArgumentList '-show' -Wait -ErrorAction SilentlyContinue
Write-Host "완료. 아이콘이 바로 바뀌지 않으면 탐색기를 다시 열거나 재부팅하세요."
